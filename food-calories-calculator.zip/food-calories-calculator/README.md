# Food Calories Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/mighty123gun/pen/GRXZYRQ](https://codepen.io/mighty123gun/pen/GRXZYRQ).

